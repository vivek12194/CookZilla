<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cookzilla";
$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$f = $_POST['fname'];
$l =$_POST ['lname'];

$e = $_POST ['email'];
$pass=$_POST['pwd'];
$p = md5($pass);
$b = $_POST['bio'];
$n = $_SESSION['username'];

//echo mysqli_num_rows($result11);
$sql = "UPDATE users set firstname ='$f', lastname ='$l', email ='$e', password ='$p', bio='$b' where uname ='$n' ";
$res=mysqli_query($conn, $sql);

header("location: ../final/user.php?=updated");
die();

if(!$res){
	echo"query failed";
}
else {

	echo "ata inserted";
}


//$res=mysqli_query($conn, $sql);
//if(!$res){
	//echo"query failed";
//}+
//else {
//	echo " data inserted";
//}









$conn->close();


?>
