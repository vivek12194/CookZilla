<?php

if($_SESSION['username']==null)
{
	header("location: ../final/login.php");
}
?>
